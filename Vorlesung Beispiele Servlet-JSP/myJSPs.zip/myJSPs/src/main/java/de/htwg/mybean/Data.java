package de.htwg.mybean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Data implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -862380378676997665L;
	
	private List<String> dataList = new ArrayList<String>();

	public Data() {
		dataList.add("Frederike Maier");
		dataList.add("Frederike Maier");
		dataList.add("Manfred M�ller");
		dataList.add("Sabine Musterfrau");
		dataList.add("Walter Mustermann");
	}

	public List<String> getDataList() {
		return dataList;
	}

	public void setDataList(List<String> dataList) {
		this.dataList = dataList;
	}
}
